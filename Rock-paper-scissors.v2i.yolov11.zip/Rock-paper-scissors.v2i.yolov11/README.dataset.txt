# Rock-paper-scissors > 2022-08-18 1:58pm
https://universe.roboflow.com/hiraki/rock-paper-scissors-rbzgd

Provided by a Roboflow user
License: CC BY 4.0

